WEBSITE PEMESANAN KAFE — PANDUAN SINGKAT

ISI FOLDER
- index.html
- style.css
- script.js

JALANKAN DI VS CODE
1. Ekstrak ZIP ke folder di komputer.
2. VS Code > File > Open Folder > pilih folder hasil ekstrak.
3. Pasang ekstensi Live Server (Ctrl+Shift+X).
4. Klik kanan index.html > Open with Live Server.

UPLOAD GRATIS KE NETLIFY
1. Buka https://app.netlify.com/drop
2. Login/daftar agar situs bisa dikelola lagi nanti.
3. Seret folder hasil ekstrak (folder yang berisi index.html, style.css, script.js) ke area upload.
4. Tunggu sampai Netlify memberi URL publik.
5. Buka URL tersebut dari HP untuk mengetes.

QR CODE MEJA
Setelah mendapat URL situs, misalnya https://nama-situs.netlify.app
- Meja 01: https://nama-situs.netlify.app/?meja=01
- Meja 02: https://nama-situs.netlify.app/?meja=02
- Meja 03: https://nama-situs.netlify.app/?meja=03

Masukkan setiap URL ke generator QR Code, lalu cetak.

PENTING
Versi ini adalah DEMO frontend. Pesanan disimpan di localStorage browser, bukan database online.
Artinya pesanan dari HP pelanggan TIDAK akan otomatis muncul di perangkat admin. Halaman admin juga belum diamankan dengan login.
Jangan gunakan untuk transaksi/operasional nyata sebelum backend/database online dan autentikasi admin ditambahkan.
