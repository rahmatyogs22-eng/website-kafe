const menu=[
{id:1,name:"Kopi Susu",desc:"Espresso dan susu creamy",price:18000,emoji:"☕"},
{id:2,name:"Americano",desc:"Kopi hitam pilihan",price:15000,emoji:"🧊"},
{id:3,name:"Cappuccino",desc:"Kopi dengan foam susu",price:22000,emoji:"🥛"},
{id:4,name:"Matcha Latte",desc:"Matcha dan susu segar",price:23000,emoji:"🍵"},
{id:5,name:"Croissant",desc:"Pastry renyah dan lembut",price:17000,emoji:"🥐"},
{id:6,name:"Kentang Goreng",desc:"Camilan gurih",price:16000,emoji:"🍟"}
];
const params=new URLSearchParams(location.search);
const table=params.get("meja")||"Online";
const isAdmin=params.get("admin")==="1";
const cart={};
const rupiah=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
const safe=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const customerPage=document.getElementById("customerPage");
const adminPage=document.getElementById("adminPage");
if(isAdmin){customerPage.hidden=true;adminPage.hidden=false;renderOrders();}
else{
 document.getElementById("tableLabel").textContent=table==="Online"?"Pesanan online":"Meja "+table;
 renderMenu();renderCart();
}
function renderMenu(){
 document.getElementById("menuList").innerHTML=menu.map(item=>`
 <article class="menu-card"><div class="food-emoji">${item.emoji}</div><h3>${item.name}</h3>
 <p>${item.desc}</p><div class="price">${rupiah(item.price)}</div>
 <button class="add-btn" onclick="addToCart(${item.id})">+ Tambah</button></article>`).join("");
}
function addToCart(id){cart[id]=(cart[id]||0)+1;renderCart();}
function changeQty(id,amount){cart[id]=(cart[id]||0)+amount;if(cart[id]<=0)delete cart[id];renderCart();}
function renderCart(){
 const items=menu.filter(item=>cart[item.id]);
 const total=items.reduce((sum,item)=>sum+item.price*cart[item.id],0);
 document.getElementById("cartList").innerHTML=items.length?items.map(item=>`
 <div class="cart-row"><div><strong>${item.name}</strong><br>${rupiah(item.price*cart[item.id])}</div>
 <div><button class="secondary" aria-label="Kurangi ${item.name}" onclick="changeQty(${item.id},-1)">−</button>
 ${cart[item.id]}<button class="secondary" aria-label="Tambah ${item.name}" onclick="changeQty(${item.id},1)">+</button></div></div>`).join(""):'<div class="empty">Belum ada pesanan. Yuk pilih menu!</div>';
 document.getElementById("total").textContent=rupiah(total);
}
document.getElementById("orderForm").addEventListener("submit",event=>{
 event.preventDefault();
 const items=menu.filter(item=>cart[item.id]).map(item=>({name:item.name,price:item.price,qty:cart[item.id]}));
 if(!items.length){alert("Pilih menu terlebih dahulu!");return;}
 const name=document.getElementById("customerName").value.trim();
 if(!name){alert("Masukkan nama pelanggan!");return;}
 const order={id:Date.now(),name,table,notes:document.getElementById("notes").value.trim(),items,
 total:items.reduce((sum,item)=>sum+item.price*item.qty,0),status:"Menunggu",time:new Date().toLocaleString("id-ID")};
 // DEMO: localStorage hanya menyimpan data di browser/perangkat ini.
 const orders=JSON.parse(localStorage.getItem("cafeOrders")||"[]");
 orders.unshift(order);localStorage.setItem("cafeOrders",JSON.stringify(orders));
 document.getElementById("message").textContent="Pesanan demo tersimpan di browser ini. Nomor: "+order.id+". Pesanan belum dikirim ke admin online.";
 Object.keys(cart).forEach(id=>delete cart[id]);renderCart();event.target.reset();
});
function renderOrders(){
 const orders=JSON.parse(localStorage.getItem("cafeOrders")||"[]");
 const target=document.getElementById("ordersList");
 if(!orders.length){target.innerHTML='<p class="empty">Belum ada pesanan di browser ini.</p>';return;}
 target.innerHTML=orders.map(order=>`<article class="order-row"><h3>Pesanan #${order.id}</h3>
 <p><strong>${safe(order.name)}</strong> · Meja ${safe(order.table)}</p><p>${safe(order.time)}</p>
 <p>${order.items.map(item=>`${safe(item.name)} × ${item.qty}`).join("<br>")}</p>
 <p>Catatan: ${safe(order.notes||"-")}</p><h3>${rupiah(order.total)}</h3><p class="status">Status: ${safe(order.status)}</p>
 <button class="secondary" onclick="updateStatus(${order.id})">Ubah status</button></article>`).join("");
}
function updateStatus(id){
 const orders=JSON.parse(localStorage.getItem("cafeOrders")||"[]");
 const order=orders.find(item=>item.id===id);if(!order)return;
 const statuses=["Menunggu","Diproses","Siap disajikan","Selesai"];
 order.status=statuses[(statuses.indexOf(order.status)+1)%statuses.length];
 localStorage.setItem("cafeOrders",JSON.stringify(orders));renderOrders();
}
document.getElementById("refreshOrders").addEventListener("click",renderOrders);
